package javaBasicTopics.Day6;

public class ArraysEx {

	public static void main(String[] args) {
		
		int[] arr=new int[] {1,2,3,4,5,6,77};
		
		for(int a:arr) {
			System.out.println(a);
		}
	}

}
