package javaBasicTopics.Day5;


final class a{
	
}

class b extends a   //The type b cannot subclass the final class a
{
	
}



public class finalclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
