package javaBasicTopics.Day2;

public class Demo2 {

	public static void main(String[] args) {
		
	}

}
