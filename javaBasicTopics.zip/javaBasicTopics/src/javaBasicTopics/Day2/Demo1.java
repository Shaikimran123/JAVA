package javaBasicTopics.Day2;

public class Demo1 {

	public static void main(String[] args) {

		String x="525";
		int i=Integer.parseInt(x);
		
		System.out.println(i+1);
		System.out.println(x+1);	
		
		String a="Hello";
		int y=Integer.parseInt(a);
		//number format exception .. which type casting ensure the type is compatible

	}

}
