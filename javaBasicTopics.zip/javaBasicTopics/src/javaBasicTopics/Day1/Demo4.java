package javaBasicTopics.Day1;

public class Demo4 {
	
	int x; 	
	public Demo4() {

		x=10;
	}
	
	void disp(){
		System.out.println(x);
	}

	public static void main(String[] args) {
	
		Demo4 m=new Demo4();
		m.disp();

	}

}
